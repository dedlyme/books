<?php
// Require necessary files
require "core/Database.php";
$config = require "config.php";

// Check if 'id' parameter is set in the URL
if(isset($_GET['id'])) {
    // Create a new instance of the Database class
    $db = new Database($config);

    // Get the book ID from the URL parameters
    $bookId = $_GET["id"];

    // Prepare the query to fetch the book details
    $query = "SELECT * FROM books WHERE id = :id";
    $params = [":id" => $bookId];

    // Execute the query and fetch the book details
    $book = $db->execute($query, $params)->fetch();

    // Check if the book exists
    if ($book) {
        // Book found, display its details
        echo "<h1>" . htmlspecialchars($book["name"]) . "</h1>";
        echo "<p>Authors: " . htmlspecialchars($book["authors"]) . "</p>";
        echo "<p>Year Came Out: " . htmlspecialchars($book["year_came_out"]) . "</p>";
    } else {
        // Book not found, display an error message
        echo "Book not found.";
    }
} else {
    // If 'id' parameter is not set, display an error message
    echo "Error: Book ID not provided.";
}
?>