<?php

session_start();


require "core/functions.php";
require "core/router.php";