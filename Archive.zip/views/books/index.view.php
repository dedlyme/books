<?php require "views/components/head.php" ?>
<?php require "views/components/navbar.php"?>

<h1>Books</h1>

<ul>
<?php foreach($posts as $post) { ?>
  <li>
    <a href="/show?id=<?= $post["id"] ?>"><?php echo htmlspecialchars($post["name"]) . " by " . htmlspecialchars($post["authors"]) . " (" . htmlspecialchars($post["year_came_out"]) . ")"; ?></a>
    <form class="delete-form" method="POST" action="/delete">
      <input type="hidden" name="id" value="<?= $post["id"] ?>">
      <button type="submit">Delete</button>
    </form>
  </li>
<?php } ?>
</ul>

<?php require "views/components/footer.php" ?>