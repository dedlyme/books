<?php require "views/components/head.php" ?>
<?php require "views/components/navbar.php" ?>

<?php if ($book): ?>
    <h1><?= htmlspecialchars($book["name"]) ?></h1>
    <p>Year Released: <?= htmlspecialchars($book["year_came_out"]) ?></p>
    <p>Authors: <?= htmlspecialchars($book["authors"]) ?></p>
    
    <a href="/edit?id=<?= $book["id"] ?>">Edit</a>
<?php else: ?>
    <p>Book not found.</p>
<?php endif; ?>

<?php require "views/components/footer.php" ?>