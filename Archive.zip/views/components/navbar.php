<header>
    <nav>
        <a href="/">books</a>
        <a href="/create">add a book</a>
        <a href="/login">login</a>
        <a href="/register">register</a>
        <a href="/logout">logout</a>
    </nav>
</header>